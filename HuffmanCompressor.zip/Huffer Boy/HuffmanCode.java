// Tyler Bunnell
// 3/14/2019
// CSE143
// TA:  Zaha Wolfe
// Assignment #8
//
// A class that represents a huffman code that compresses data.

import java.util.*;
import java.io.*;

public class HuffmanCode {
   
   private HuffmanNode combinedNode;
   
   // Post: Constructs a HuffmanCode object when given the frequencies of characters
   //
   // Parameter: int[] frequencies - an int array with how many times each character shows up
   //                                in the file 
   public HuffmanCode(int[] frequencies) {
      Queue<HuffmanNode> nodeQueue = new PriorityQueue<>();
      for (int i = 0; i < frequencies.length; i++) {
         if (frequencies[i] > 0) {
            nodeQueue.add(new HuffmanNode(i, frequencies[i]));
         }
      }
      buildTree(nodeQueue);
   }
   
   // Post: Constructs a HuffmanCode object out of a file
   //
   // Parameter: Scanner input: Scanner for a file
   public HuffmanCode(Scanner input) {
      combinedNode = new HuffmanNode();
      HuffmanNode temp = combinedNode;
      while (input.hasNextLine()) {
         int asciiValue = Integer.parseInt(input.nextLine());
         String code = input.nextLine();
         for (int i = 0; i < code.length(); i++) {
            if (code.charAt(i) == '0') {
               if (temp.zero == null) {
                  temp.zero = new HuffmanNode();
               }
               temp = temp.zero;
            } else {
               if (temp.one == null) {
                  temp.one = new HuffmanNode();
               }
               temp = temp.one;
            }
         }
         temp.ascii = asciiValue;
         temp = combinedNode;
      }
   }
   
   // Post: Builds a HuffmanNode tree
   //
   // Parameter: Queue<HuffmanNode> nodeQueue - a priority queue filled with HuffmanNodes
   private void buildTree(Queue<HuffmanNode> nodeQueue) {
      while (nodeQueue.size() > 1) {
         HuffmanNode combinedNode = new HuffmanNode();
         combinedNode.zero = nodeQueue.remove();
         combinedNode.one = nodeQueue.remove();
         combinedNode.frequency = combinedNode.zero.frequency + combinedNode.one.frequency;
         nodeQueue.add(combinedNode);
      }
      combinedNode = nodeQueue.remove();
   }
   
   // Post: stores the current huffman codes to the given output stream in the standard format
   //
   // Parameter: PrintStream output - the print stream that outputs into a file
   public void save(PrintStream output) {
      save(output, combinedNode, "");
   }
   
   // Post: stores the current huffman codes to the given output stream in the standard format
   //
   // Parameter: PrintStream output - the print stream that outputs into a file
   //            HuffmanNode combinedNode - a tree of HuffmanNodes
   //            String soFar - a string of 1's and 0's
   private void save(PrintStream output, HuffmanNode combinedNode, String soFar){
      if (combinedNode.ascii != 0) {
         output.println(combinedNode.ascii);
         output.println(soFar);
      } else {
         save(output, combinedNode.zero, soFar + "0");
         save(output, combinedNode.one, soFar + "1");
      }      
   }
   
   // Post: reads individual bits from the input stream and writes 
   //       the corresponding characters to the output
   //
   // Parameters: BitInputStream input - input that reads bits
   //             PrintStream output - the print stream that outputs into a file
   public void translate(BitInputStream input, PrintStream output) {
      HuffmanNode temp = combinedNode;
      while (input.hasNextBit()) {
         int bit = input.nextBit();
         if (bit == 0) {
            temp = temp.zero;
         } else {
            temp = temp.one;
         }
         if (temp.zero == null && temp.one == null) {
            output.write(temp.ascii);
            temp = combinedNode;
         }         
      }
   }
   
   // This class is used to build the nodes for the tree for the HuffmanCode
   private static class HuffmanNode implements Comparable<HuffmanNode> {
      public int ascii; // The character that is in the node with it's ascii number
      public int frequency; // The amount of times that character appears in the code
      public HuffmanNode zero; // The left subtree for the zero branches
      public HuffmanNode one; // The right subtree fo the one  branches
         
      // Constructs a HuffmanNode with the given data and subtrees
      public HuffmanNode(int ascii, int frequency, HuffmanNode zero, HuffmanNode one) {
         this.ascii = ascii;
         this.frequency = frequency;
         this.zero = zero;
         this.one = one;
       }
         
      // Constructs a QuestionNode with the given data
      public HuffmanNode(int ascii, int frequency) {
          this(ascii, frequency, null, null);
      }
      
      // Constructs a HuffmanNode with no ascii letter but with a frequency
      public HuffmanNode(int frequency) {
         this(0, frequency, null, null);
      }
      
      // Constructs an empty HuffmanNode
      public HuffmanNode() {
         this(0, 0, null, null);
      }
      
      // Compares two HuffmanNodes prioritizing a lower frequency
      public int compareTo(HuffmanNode other) {
         return Integer.compare(this.frequency, other.frequency);
      }
   }
}